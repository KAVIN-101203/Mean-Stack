import { Component } from '@angular/core';

@Component({
  selector: 'app-detail-providers',
  templateUrl: './detail-providers.component.html',
  styles: [
  ]
})
export class DetailProvidersComponent {

}
