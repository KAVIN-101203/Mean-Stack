import { Component } from '@angular/core';

@Component({
  selector: 'app-delete-providers',
  templateUrl: './delete-providers.component.html',
  styles: [
  ]
})
export class DeleteProvidersComponent {

}
